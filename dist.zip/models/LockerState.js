"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LockerState = void 0;
var LockerState;
(function (LockerState) {
    LockerState[LockerState["undefined"] = 0] = "undefined";
    LockerState[LockerState["closed"] = 1] = "closed";
    LockerState[LockerState["open"] = 2] = "open";
    LockerState[LockerState["openrequested"] = 3] = "openrequested";
})(LockerState = exports.LockerState || (exports.LockerState = {}));
