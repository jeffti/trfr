"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Slot = void 0;
class Slot {
    constructor() {
        this.code = '';
        this.desiredOpen = false;
        this.reportedOpen = false;
        this.componentCommand = null;
        this.componentState = null;
        this.portCommand = 0;
        this.portState = 0;
    }
}
exports.Slot = Slot;
