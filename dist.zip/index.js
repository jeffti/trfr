"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
const server_1 = require("./server");
dotenv_1.default.config({ path: path_1.default.resolve(process.cwd(), './.env') });
const exec = async () => {
    const server = new server_1.Server();
    const createServerAndStartIt = async () => {
        await server.register();
        await server.loop();
    };
    const destroy = () => {
        server.destroy();
    };
    await createServerAndStartIt();
    process.on('SIGINT', async () => {
        destroy();
    });
    return {
        server,
        destroy,
    };
};
exports.default = exec();
