"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestService = void 0;
const axios_1 = __importDefault(require("axios"));
class RequestService {
    constructor(baseUrl) {
        this.instance = axios_1.default.create({
            baseURL: baseUrl,
            timeout: 60000,
        });
    }
    getInstance() {
        return this.instance;
    }
    async get(path, params, headers = {}) {
        return this.instance.get(path, {
            params,
            headers,
        });
    }
    async post(path, data, headers = {}) {
        return this.instance.post(path, data, {
            headers,
        });
    }
    async put(path, params, data, headers = {}) {
        return this.instance.put(path, data, {
            params,
            headers,
        });
    }
    async delete(path, params, headers = {}) {
        return this.instance.delete(path, {
            params,
            headers,
        });
    }
}
exports.RequestService = RequestService;
