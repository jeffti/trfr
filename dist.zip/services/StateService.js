"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StateService = void 0;
const ComponentService_1 = require("./ComponentService");
const promises_1 = require("timers/promises");
const LockerState_1 = require("../models/LockerState");
class StateService {
    constructor(state) {
        this.slots = state;
        this.componentService = new ComponentService_1.ComponentService();
    }
    async updateStates(state) {
        const newStates = [];
        for (const slot of state) {
            const found = this.slots.find((s) => {
                return slot.code === s.code;
            });
            if (found) {
                const reportedState = this.componentService.getState(found);
                if (slot.desiredState === LockerState_1.LockerState.open && reportedState === LockerState_1.LockerState.closed) {
                    found.desiredState = slot.desiredState;
                    await this.componentService.setState(found);
                    await (0, promises_1.setTimeout)(500);
                    found.reportedState = this.componentService.getState(found);
                    newStates.push(found);
                }
            }
        }
        return newStates;
    }
    clear() {
        for (const slot of this.slots) {
            this.componentService.clearState(slot);
        }
        this.slots = [];
    }
}
exports.StateService = StateService;
