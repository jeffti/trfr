"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StateService = void 0;
const ComponentService_1 = require("./ComponentService");
const promises_1 = require("timers/promises");
class StateService {
    constructor(state) {
        this.slots = state;
        this.componentService = new ComponentService_1.ComponentService();
    }
    async updateStates(state) {
        const newStates = [];
        for (const slot of state) {
            const found = this.slots.find((s) => {
                return slot.code === s.code;
            });
            if (found) {
                let refreshState = false;
                if (slot.desiredOpen) {
                    found.desiredOpen = true;
                    await this.componentService.setState(found);
                    await (0, promises_1.setTimeout)(500);
                    refreshState = true;
                }
                this.componentService.updateState(found);
                if (slot.reportedOpen) {
                    if (!found.reportedOpen) {
                        refreshState = true;
                    }
                }
                if (refreshState) {
                    newStates.push(found);
                }
            }
        }
        return newStates;
    }
    clear() {
        for (const slot of this.slots) {
            this.componentService.clearState(slot);
        }
        console.info(`Cleared component states`);
        this.slots = [];
    }
}
exports.StateService = StateService;
