"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceService = void 0;
const os_1 = require("os");
const common_api_1 = require("@cleeanapp/common-api");
class ServerCredentialServiceA extends common_api_1.ServerCredentialService {
    initialize() {
    }
}
class DeviceService {
    constructor(code, networkDeviceName) {
        this.code = code;
        this.networkDeviceName = networkDeviceName;
        this.authService = new common_api_1.AuthService(new ServerCredentialServiceA(), new common_api_1.ClientCredentialService());
        this.lockerRequestService = new common_api_1.LockerRequestService(this.authService);
    }
    async register() {
        console.log(`Registering device '${this.code}'`);
        try {
            const response = await this.lockerRequestService.post(`device/register/${this.code}`, {
                ipAddress: this.getIpAddress(),
            });
            if (response.data.status === 1) {
                this.customToken = response.data.result.token;
                console.log(`Device registered and initialized`);
                return;
            }
            throw new Error(`Failed to register device - Details: ${response.status} - ${JSON.stringify(response.data)}`);
        }
        catch (exception) {
            throw new Error(`Register - Invalid request to collect device status - Details ${exception}`);
        }
    }
    async request() {
        if (!this.customToken) {
            throw new Error('Service initialization failure');
        }
        try {
            const token = await this.authService.getClientJwtToken(this.customToken);
            const response = await this.lockerRequestService.get(`device/${this.code}`, {}, { Authorization: `Bearer ${token}` });
            if (response.data.status === 1) {
                return response.data.result;
            }
            throw new Error(`Failed to collect device state - Details: ${response.status} - ${JSON.stringify(response.data)}`);
        }
        catch (exception) {
            throw new Error(`Request - Invalid request to collect device status - Details ${exception}`);
        }
    }
    async reportState(state) {
        if (!this.customToken) {
            throw new Error('Service initialization failure');
        }
        try {
            const token = await this.authService.getClientJwtToken(this.customToken);
            const response = await this.lockerRequestService.post(`device/${this.code}`, { slots: state }, {
                Authorization: `Bearer ${token}`,
            });
            const result = response.data;
            if (result && result.status === 1) {
                return result.result;
            }
            throw new Error(`Failed to report device state - Details: ${response.status} - ${JSON.stringify(response.data)}`);
        }
        catch (exception) {
            throw new Error(`Invalid request to report device status - Details ${exception}`);
        }
    }
    getIpAddress() {
        var interfaces = (0, os_1.networkInterfaces)();
        for (const entry of Object.keys(interfaces)) {
            if (entry === this.networkDeviceName) {
                for (const device of interfaces[entry]) {
                    if (device.family === 'IPv4')
                        return device.address;
                }
            }
        }
        console.warn(`Ip Address from device '${this.networkDeviceName}' not found`);
    }
}
exports.DeviceService = DeviceService;
