"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceService = void 0;
const os_1 = require("os");
const RequestService_1 = require("./RequestService");
const AuthService_1 = require("./AuthService");
class DeviceService {
    constructor(code, networkDeviceName) {
        this.code = code;
        this.networkDeviceName = networkDeviceName;
        this.authService = new AuthService_1.AuthService();
        const baseUrl = process.env.LOCKER_ENDPOINT;
        if (!baseUrl) {
            throw new Error('Invalid authentication url');
        }
        this.requestService = new RequestService_1.RequestService(baseUrl);
    }
    async register() {
        console.log(`Registering device '${this.code}'`);
        try {
            const response = await this.requestService.post(`device/register/${this.code}`, {
                ipAddress: this.getIpAddress(),
            });
            const result = response.data;
            if (result && result.status === 1) {
                await this.authService.initialize(result.result.token);
                console.log(`Device registered and initialized`);
                return;
            }
            throw new Error(`Failed to register device - Details: ${response.status} - ${JSON.stringify(response.data)}`);
        }
        catch (exception) {
            throw new Error(`Register - Invalid request to collect device status - Details ${exception}`);
        }
    }
    async request() {
        const token = await this.authService.getToken();
        try {
            const response = await this.requestService.get(`device/${this.code}`, {}, { Authorization: `Bearer ${token}` });
            const result = response.data;
            if (result && result.status === 1) {
                return result.result;
            }
            throw new Error(`Failed to collect device state - Details: ${response.status} - ${JSON.stringify(response.data)}`);
        }
        catch (exception) {
            throw new Error(`Request - Invalid request to collect device status - Details ${exception}`);
        }
    }
    async reportState(state) {
        const token = await this.authService.getToken();
        try {
            const response = await this.requestService.post(`device/${this.code}`, { slots: state }, {
                Authorization: `Bearer ${token}`,
            });
            const result = response.data;
            if (result && result.status === 1) {
                return result.result;
            }
            throw new Error(`Failed to report device state - Details: ${response.status} - ${JSON.stringify(response.data)}`);
        }
        catch (exception) {
            throw new Error(`Invalid request to report device status - Details ${exception}`);
        }
    }
    getIpAddress() {
        var interfaces = (0, os_1.networkInterfaces)();
        for (const entry of Object.keys(interfaces)) {
            if (entry === this.networkDeviceName) {
                for (const device of interfaces[entry]) {
                    if (device.family === 'IPv4')
                        return device.address;
                }
            }
        }
        console.warn(`Ip Address from device '${this.networkDeviceName}' not found`);
    }
}
exports.DeviceService = DeviceService;
