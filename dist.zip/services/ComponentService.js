"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ComponentService = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const onoff_1 = require("onoff");
const promises_1 = require("timers/promises");
class ComponentService {
    updateState(slot) {
        this.initSlot(slot);
        console.log(`Getting slot state ${slot.code}`);
        let state;
        if (!process.env.simulation) {
            state = slot.componentState?.readSync();
        }
        else {
            const statePath = path_1.default.join(process.cwd(), './state.json');
            const fileState = JSON.parse(fs_1.default.readFileSync(statePath, 'utf-8'));
            const s = fileState.slots.find((i) => {
                return i.code === slot.code;
            });
            state = s.state;
            console.warn(`Read simulated on platform ${process.platform} - state: ${s.state}`);
        }
        slot.reportedOpen = state === ComponentService.OPENED;
    }
    async setState(slot) {
        this.initSlot(slot);
        if (slot.desiredOpen) {
            console.log(`Setting slot open ${slot.code}`);
            if (!process.env.simulation) {
                slot.componentCommand?.writeSync(ComponentService.OPENED);
                await (0, promises_1.setTimeout)(500);
                slot.componentCommand?.writeSync(ComponentService.CLOSED);
            }
            else {
                console.warn(`Write Open not executed on platform ${process.platform}`);
            }
        }
        else {
            console.log(`Setting slot closed ${slot.code}`);
            if (!process.env.simulation) {
                slot.componentCommand?.writeSync(ComponentService.CLOSED);
            }
            else {
                console.warn(`Write Close not executed on platform ${process.platform}`);
            }
        }
    }
    initSlot(slot) {
        if (!slot.componentCommand) {
            console.log(`Initiating slot command ${slot.code}`);
            if (!process.env.simulation) {
                slot.componentCommand = new onoff_1.Gpio(slot.portCommand, 'out');
                slot.componentCommand?.writeSync(ComponentService.CLOSED);
            }
            else {
                console.warn(`Init Command not executed on platform ${process.platform}`);
                slot.componentCommand = 1;
            }
        }
        if (!slot.componentState) {
            console.log(`Initiating slot state ${slot.code}`);
            if (!process.env.simulation) {
                slot.componentState = new onoff_1.Gpio(slot.portState, 'in');
            }
            else {
                console.warn(`Init State not executed on platform ${process.platform}`);
                slot.componentState = 1;
            }
        }
    }
    clearState(slot) {
        if (!process.env.simulation) {
            slot.componentCommand?.unexport();
            slot.componentState?.unexport();
        }
        else {
            console.warn(`Clear not executed on platform ${process.platform}`);
        }
    }
}
exports.ComponentService = ComponentService;
ComponentService.OPENED = 0;
ComponentService.CLOSED = 1;
