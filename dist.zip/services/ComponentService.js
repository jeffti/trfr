"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ComponentService = void 0;
const onoff_1 = require("onoff");
const promises_1 = require("timers/promises");
class ComponentService {
    updateState(slot) {
        this.initSlot(slot);
        console.log(`Getting slot state ${slot.code}`);
        let state;
        if (process.platform === 'linux') {
            state = slot.componentState?.readSync();
        }
        else {
            console.warn(`Read not executed on platform ${process.platform}`);
        }
        slot.reportedOpen = state === ComponentService.OPENED;
    }
    async setState(slot) {
        this.initSlot(slot);
        if (slot.desiredOpen) {
            console.log(`Setting slot open ${slot.code}`);
            if (process.platform === 'linux') {
                slot.componentCommand?.writeSync(ComponentService.OPENED);
                await (0, promises_1.setTimeout)(500);
                slot.componentCommand?.writeSync(ComponentService.CLOSED);
            }
            else {
                console.warn(`Write Open not executed on platform ${process.platform}`);
            }
        }
        else {
            console.log(`Setting slot closed ${slot.code}`);
            if (process.platform === 'linux') {
                slot.componentCommand?.writeSync(ComponentService.CLOSED);
            }
            else {
                console.warn(`Write Close not executed on platform ${process.platform}`);
            }
        }
    }
    initSlot(slot) {
        if (!slot.componentCommand) {
            console.log(`Initiating slot command ${slot.code}`);
            if (process.platform === 'linux') {
                slot.componentCommand = new onoff_1.Gpio(slot.portCommand, 'out');
                slot.componentCommand?.writeSync(ComponentService.CLOSED);
            }
            else {
                console.warn(`Init Command not executed on platform ${process.platform}`);
            }
        }
        if (!slot.componentState) {
            console.log(`Initiating slot state ${slot.code}`);
            if (process.platform === 'linux') {
                slot.componentState = new onoff_1.Gpio(slot.portState, 'in');
            }
            else {
                console.warn(`Init State not executed on platform ${process.platform}`);
            }
        }
    }
    clearState(slot) {
        if (process.platform === 'linux') {
            slot.componentCommand?.unexport();
            slot.componentState?.unexport();
        }
        else {
            console.warn(`Clear not executed on platform ${process.platform}`);
        }
    }
}
exports.ComponentService = ComponentService;
ComponentService.OPENED = 0;
ComponentService.CLOSED = 1;
