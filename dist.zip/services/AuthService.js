"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const app_1 = require("firebase/app");
const auth_1 = require("firebase/auth");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
class AuthService {
    constructor() {
        this.credentials = null;
    }
    async initialize(customToken) {
        const configPath = path_1.default.join(process.cwd(), './firebase.json');
        const firebaseConfig = JSON.parse(fs_1.default.readFileSync(configPath, 'utf-8'));
        const app = (0, app_1.initializeApp)(firebaseConfig);
        const auth = (0, auth_1.getAuth)(app);
        console.log(`Collecting device credentials`);
        this.credentials = await (0, auth_1.signInWithCustomToken)(auth, customToken);
        console.log(`Credentials update successfully`);
    }
    async getToken() {
        if (!this.credentials) {
            throw new Error('Initialization incomplete');
        }
        console.log(`Collecting token`);
        return this.credentials.user.getIdToken();
    }
}
exports.AuthService = AuthService;
