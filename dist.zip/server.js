"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Server = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const DeviceService_1 = require("./services/DeviceService");
const StateService_1 = require("./services/StateService");
class Server {
    constructor() {
        const statePath = path_1.default.join(process.cwd(), './state.json');
        const state = JSON.parse(fs_1.default.readFileSync(statePath, 'utf-8'));
        if (!state.code) {
            throw new Error('Initialization error, invalid device code');
        }
        if (!state.intervalMs || state.intervalMs < 1000) {
            throw new Error(`Interval for state update invalid - Value '${state.intervalMs}`);
        }
        console.info(`Execution interval set to '${state.intervalMs}' ms`);
        this.intervalMs = state.intervalMs;
        this.deviceService = new DeviceService_1.DeviceService(state.code, state.networkDeviceName);
        this.stateService = new StateService_1.StateService(state.slots);
    }
    async register() {
        await this.deviceService.register();
        await this.updateAndReportStates();
    }
    destroy() {
        this.stateService.clear();
        clearInterval(this.intervalEvent);
    }
    async loop() {
        if (this.intervalEvent) {
            return;
        }
        this.intervalEvent = setInterval(async () => {
            this.updateAndReportStates()
                .then(() => {
                console.info(`State update completed`);
            })
                .catch((e) => {
                console.error(`Failed to update device state ${e}`);
            });
        }, this.intervalMs);
    }
    async updateAndReportStates() {
        console.info(`Collecting device state`);
        const state = await this.deviceService.request();
        console.log(`${state.length} states collected, updating device`);
        const newStates = await this.stateService.updateStates(state);
        console.log(`${newStates.length} new states update, reporting device`);
        if (newStates.length > 0) {
            await this.deviceService.reportState(newStates);
        }
    }
}
exports.Server = Server;
